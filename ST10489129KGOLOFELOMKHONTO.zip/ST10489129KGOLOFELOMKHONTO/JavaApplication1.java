
package javaapplication1;

import java.util.Scanner;
import javax.swing.JOptionPane;



public class JavaApplication1 
{

  public static void main(String[] args){
        validator validator = new validator();
        Scanner scan = new Scanner(System.in);
   // Registration phase
   do {
     System.out.print("Please enter a username (include underscore, max 5 chars): ");
     validator.userName = scan.nextLine();
     } while (!validator.isUserNameValid());

   do{
            System.out.print("Enter password(ensure it contains....): ");
            validator.registerpassword = scan.nextLine();
        }while(!validator.checkPassword());
       
   do {
      System.out.print("Please enter phone number (9 digits): +27");
      validator.phoneNumber = scan.nextLine();
   } while (!validator.isPhoneNumberValid());

      System.out.print("Enter your first name: ");
      validator.firstName = scan.nextLine();

      System.out.print("Enter your last name: ");
      validator.lastName = scan.nextLine();

      System.out.println(validator.getRegistrationMessage());

     // Login phase
   do {
      System.out.print("Login username: ");
      validator.loginName = scan.nextLine();

      System.out.print("Login password: ");
      validator.loginPass = scan.nextLine();
      System.out.println(validator.getLoginMessage());
    } while (!validator.isLoginCorrect());

      boolean exitProgram = false;

      while (!exitProgram) {
        System.out.println("1) Send Messages \n2) View Messages \n3) Exit");
      int userChoice = scan.nextInt();

      if (userChoice == 1) {
         System.out.print("How many messages do you want to send? ");
      int totalMessages = scan.nextInt();
          scan.nextLine(); // consume newline
        TextMessage[] messageList = new TextMessage[totalMessages];

      for (int i = 0; i < totalMessages; i++) {
        TextMessage textMsg = new TextMessage();
      boolean validRecipient = false;
   do {
       System.out.print("Enter recipient phone number (9 digits): +27");
       textMsg.recipientPhone = scan.nextInt();
       scan.nextLine(); // consume newline
       String fullNumber = "+27" + textMsg.recipientPhone;
     if (fullNumber.length() == 12) {
      validRecipient = true;
     } else {
      System.out.println("Invalid phone number. Please try again.");
     }
                    
   } while (!validRecipient);

   do {
      System.out.print("Enter your message (max 50 chars): ");
      textMsg.messageContent = scan.nextLine();
                    
   } while (!textMsg.isValidLength());

      System.out.println("Choose message option: \n1) Send \n2) Save \n3)Discard");
      int statusChoice = scan.nextInt();
       scan.nextLine(); 
      
       // consume newline
      if (statusChoice == 1) {
        textMsg.messageStatus = "Sent";
    } else if (statusChoice == 2) {
      textMsg.messageStatus = "Saved";
    } else {
    textMsg.messageStatus = "Discarded";
                    }

   messageList[i] = textMsg;

   // Show message info in JOptionPane popup
    JOptionPane.showMessageDialog(null,
    "Message ID: " + (textMsg.baseId + i)+ "\nHash: " + textMsg.generateHashCode()
                            + "\nMessage: " + textMsg.messageContent
                            + "\nRecipient: +27" + textMsg.recipientPhone,
                            "Message Details", JOptionPane.INFORMATION_MESSAGE);
      
                }
                 

          } else if (userChoice == 2) {
             System.out.println("Feature coming soon...");
              } else if (userChoice == 3) {
                   System.out.println("Thank you for using the app. Goodbye!");
                      exitProgram = true;
            }
        }
    }

}       

      

