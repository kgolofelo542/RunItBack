
package javaapplication1;


public class TextMessage {
    int baseId = 123456789;
    int recipientPhone;
    String messageContent;
    String messageStatus;

    // Check if message length <= 50 characters
    public boolean isValidLength() {
        if (messageContent.length() <= 50) {
            System.out.println("Message length OK.");
            return true;
        } else {
            System.out.println("Message too long. Max 50 chars.");
            return false;
        }
           }

    // Generate message hash: first two digits of ID + recipient + first & last word of message
    public String generateHashCode() {
        int firstSpace = messageContent.indexOf(" ");
        int lastSpace = messageContent.lastIndexOf(" ");
        String firstWord = firstSpace != -1 ? messageContent.substring(0, firstSpace) : messageContent;
        String lastWord = lastSpace != -1 ? messageContent.substring(lastSpace + 1) : messageContent;
        String idString = Integer.toString(baseId);

         String hash = idString.substring(0, 2) + ":" + recipientPhone + ":" + firstWord + lastWord;
        return hash.toUpperCase();
    }
}
