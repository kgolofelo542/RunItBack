
package javaapplication1;


public class validator{ 

   public boolean userName(String name){//if the name has a undrecore works and the words they have to be less then five
       if(name.length() <5 && name.contains("_")){
           
           System.out.println("username is saved");
           return true;
       }
       else{
           System.out.println("your username is invalid");
           
       }
       return false;
   }   
   
   
    public boolean userPassword(String password){//checking the password that the user will give
         if(password.length() >8 && password.matches(".*[A-Z].*") && password.matches(".*[0-9].*") && password.matches(".*[!@#$%^&()-+=].*")){
            
             System.out.println("userpassword is saved");
             return true;
         } 
         else{
             System.out.println("your userpassword is invalid");
         }
         return false;
             
    }  
    
    
    public boolean validatePhoneNumber(String Number){ //checking the number the user will give
        
        if(Number.matches("^\\d{9}$")){
            
            System.out.println("Number has been captured successfully");
            return true;
        }
        
        else{
            
            System.out.println("Seems the number invalid, please try again");
        }
        
        return false;
    } 
         
   }     
