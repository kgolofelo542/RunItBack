
package javaapplication1;

import java.util.Scanner;


public class JavaApplication1 
{

   
    public static void main(String[] args) 
    {
        validator user = new validator();//to bring the class to the main class
        Scanner scan = new Scanner(System.in);
        String name;
        String password;
        String phoneNumber;
        String captureduser;
        String capturedpassword;
        String firstname;
        String lastname;
        
        do{//asking you to put your name if it's wrong it will loop
        System.out.println("what is your username");
        name = scan.nextLine();
        }while(user.userName(name)==false);
       
        
        
        do{//asking you to put your password if it's wrong it will loop
        System.out.println("what is your user password");
        password = scan.nextLine();
        }while(user.userPassword(password)==false);
        
        do {//asking you to put your number if it's wrong it will loop
            System.out.print("Enter your phone number: ");
            System.out.print("+27");
            phoneNumber = scan.next();
        } while (user.validatePhoneNumber(phoneNumber) == false);
        
        System.out.println("what is your first name");//to display your question
        firstname = scan.next();
        System.out.println("what your last name");
        lastname = scan.next();
        
        
        boolean valid = false;
        
        do{
           System.out.println("what is your captured name");//to capture the first name 
           captureduser = scan.next();
        
            System.out.println("what is your captured password");//to capture the password that you did
            capturedpassword = scan.next();
            if(captureduser.equals(name) && capturedpassword.equals(password)){
            
            System.out.println("Welcome "+firstname+" "+lastname);//to welcome you when you done with the login
            valid = true;
            }
        
            else{
            System.out.println("Password or Username incorrect, try againkgolo");
            valid = false;
           }   
               
   }while(valid == false);

    }  
}
