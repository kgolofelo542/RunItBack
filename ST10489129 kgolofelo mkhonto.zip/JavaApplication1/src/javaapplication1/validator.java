
package javaapplication1;


public class validator{ 
     
    String userName, registerpassword, phoneNumber;
    String firstName, lastName;
    String loginName, loginPass;

    // Validate username: max 5 chars and contains underscore
    public boolean isUserNameValid() {
        if (userName.length() <= 5 && userName.contains("_")) {
            System.out.println("Username accepted.");
            return true;
        } else {
            System.out.println("Invalid username. Must be max 5 chars and contain '_'.");
            return false;
        }
    }

    // Validate password with at least 1 uppercase, 1 digit, 1 special char, min 8 chars
     public boolean checkPassword(){//checking the password that the user will give
         if(registerpassword.length() >8 && registerpassword.matches(".*[A-Z].*") && registerpassword.matches(".*[0-9].*") && registerpassword.matches(".*[!@#$%^&()-+=].*")){
            
             System.out.println("Password has been captured successfully");
             return true;
         } 
         else{
             System.out.println("Invalid password! Make sure it meets the minimum requirments");
        return false;
         }
       
        //class and object
    }

    // Validate phone number (exactly 9 digits)
    public boolean isPhoneNumberValid() {
        if (phoneNumber.matches("\\d{9}")) {
            System.out.println("Phone number accepted.");
            return true;
            } else {
            System.out.println("Invalid phone number. Must be 9 digits.");
            return false;
        }
    }

    // Return registration welcome message
    public String getRegistrationMessage() {
        return "Welcome " + firstName + " " + lastName + ", you have registered successfully!";
    }

    // Check if login details match registered credentials
    public boolean isLoginCorrect() {
        return loginName.equals(userName) && loginPass.equals(registerpassword);
    }

    // Return login status message
    public String getLoginMessage() {
        if (isLoginCorrect()) {
            return "Login successful! Welcome back.";
        } else {
           return " .";
        }
    }
         
   }     
