
package javaapplication1;


public class TextMessage {
    int baseId = 123456789;
    int recipientPhone;
    String messageContent;
    String messageStatus;
    String id;
    static int baseid = 1000;
    static int count = 0;
      
    // Check if message length <= 50 characters//control flow
    public boolean isValidLength() {
        if (messageContent.length() <= 50) {
            System.out.println("Message length OK.");
            return true;
        } else {
            System.out.println("Message too long. Max 50 chars.");
            return false;
        }
           }

    // Generate message hash: first two digits of ID + recipient + first & last word of message
    public String generateHashCode() {
        int firstSpace = messageContent.indexOf(" ");//finds the position of the first space in the messageContent
        int lastSpace = messageContent.lastIndexOf(" ");//finds the position of the last space in messageContent
        String firstWord = firstSpace != -1 ? messageContent.substring(0, firstSpace) : messageContent;//checks if there is space firstSpace//if yes take the first word(from index 0 to the space)
        String lastWord = lastSpace != -1 ? messageContent.substring(lastSpace + 1) : messageContent;//if a space is found you can take the word after the last space
        String idString = Integer.toString(baseId);//converts the baseID(probably an integer) to a string

         String hash = idString.substring(0, 2) + ":" + recipientPhone + ":" + firstWord + lastWord;//idString.substring(0, 2)takes the first two digits of the ID
        return hash.toUpperCase();//make all letters big 
    }
    public int generateHashCoder() {
        return messageContent != null ? messageContent.hashCode() : 0;
    }
    public boolean containsWord(String word) {
        if (messageContent == null || word == null) return false;
        String[] words = messageContent.trim().split("\\s+");
        return words.length > 0 &&
                (words[0].equalsIgnoreCase(word) ||
                 words[words.length - 1].equalsIgnoreCase(word));
    }
     public TextMessage() {
        this.id = "MSG" + (baseId + count);
        count++;
}
}
