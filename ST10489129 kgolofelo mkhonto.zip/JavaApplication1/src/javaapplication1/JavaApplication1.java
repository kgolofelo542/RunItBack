package javaapplication1;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class JavaApplication1 {

    public static void main(String[] args) {

       validator validator = new validator();
        Scanner scan = new Scanner(System.in);

        // Registration
        do {
            System.out.print("Please enter a username (include underscore, max 5 chars): ");
            validator.userName = scan.nextLine();
        } while (!validator.isUserNameValid());

        do {
            System.out.print("Enter password(ensure it contains....): ");
            validator.registerpassword = scan.nextLine();
        } while (!validator.checkPassword());

        do {
            System.out.print("Please enter phone number (9 digits): +27");
            validator.phoneNumber = scan.nextLine();
        } while (!validator.isPhoneNumberValid());

        System.out.print("Enter your first name: ");
        validator.firstName = scan.nextLine();

        System.out.print("Enter your last name: ");
        validator.lastName = scan.nextLine();

        System.out.println(validator.getRegistrationMessage());

        // Login
        do {
            System.out.print("Login username: ");
            validator.loginName = scan.nextLine();
            System.out.print("Login password: ");
            validator.loginPass = scan.nextLine();
            System.out.println(validator.getLoginMessage());
        } while (!validator.isLoginCorrect());

        // Menu loop
        boolean exitProgram = false;
        TextMessage[] messageList = new TextMessage[100]; // Max 100 messages
        int messageCount = 0;

        while (!exitProgram) {
            System.out.println("1) Send Messages \n2) View Messages \n3) Exit");
            int userChoice = scan.nextInt();
            scan.nextLine(); // consume newline

            if (userChoice == 1) {
                System.out.print("How many messages do you want to send? ");
                int totalMessages = scan.nextInt();
                scan.nextLine();

                for (int i = 0; i < totalMessages; i++) {
                    TextMessage textMsg = new TextMessage();
                    boolean validRecipient = false;

                    do {
                        System.out.print("Enter recipient phone number (9 digits): +27");
                        textMsg.recipientPhone = scan.nextInt();
                        scan.nextLine();
                        String fullNumber = "+27" + textMsg.recipientPhone;
                        validRecipient = fullNumber.length() == 12;
                        if (!validRecipient) {
                            System.out.println("Invalid phone number. Please try again.");
                        }
                    } while (!validRecipient);

                    do {
                        System.out.print("Enter your message (max 50 chars): ");
                        textMsg.messageContent = scan.nextLine();
                    } while (!textMsg.isValidLength());

                    System.out.println("Choose message option: \n1) Send \n2) Save \n3)Discard");
                    int statusChoice = scan.nextInt();
                    scan.nextLine();

                    if (statusChoice == 1) {
                        textMsg.messageStatus = "Sent";
                    } else if (statusChoice == 2) {
                        textMsg.messageStatus = "Saved";
                    } else {
                        textMsg.messageStatus = "Discarded";
                    }

                    messageList[messageCount] = textMsg;
                    messageCount++;

                    JOptionPane.showMessageDialog(null,
                            "Message ID: " + textMsg.baseId + "\nHash: " + textMsg.generateHashCode()
                                    + "\nMessage: " + textMsg.messageContent
                                    + "\nRecipient: +27" + textMsg.recipientPhone,
                            "Message Details", JOptionPane.INFORMATION_MESSAGE);
                }

            } else if (userChoice == 2) {
                System.out.println("""
                Choose option:
                1) View Sent Messages
                2) View Discarded Messages
                3) View Saved Messages
                4) Search Messages
                5) Delete Message by Hash
                6) Show Longest Message
                """);

                int subChoice = scan.nextInt();
                scan.nextLine();

                if (messageCount == 0) {
                    System.out.println("No messages to display.");
                    continue;
                }

                if (subChoice == 1 || subChoice == 2 || subChoice == 3) {
                    String target = subChoice == 1 ? "Sent" : subChoice == 2 ? "Discarded" : "Saved";
                    for (int i = 0; i < messageCount; i++) {
                        if (messageList[i] != null && messageList[i].messageStatus.equals(target)) {
                            System.out.println("ID: " + messageList[i].id + " | Message: " + messageList[i].messageContent);
                        }
                    }
                } else if (subChoice == 4) {
                    System.out.println("""
                     Search by:
                     1) First 2 digits of ID
                     2) Message Number (Index)
                     3) First or Last Word
                    """);
                    int searchType = scan.nextInt();
                    scan.nextLine();

                    if (searchType == 1) {
                        System.out.print("Enter first 2 digits of ID: ");
                        String prefix = scan.nextLine();
                        for (int i = 0; i < messageCount; i++) {
                            if (messageList[i] != null && messageList[i].id.substring(3, 5).equals(prefix)) {
                                System.out.println("ID: " + messageList[i].id + " | " + messageList[i].messageContent);
                            }
                        }
                    } else if (searchType == 2) {
                        System.out.print("Enter message number (0-based index): ");
                        int index = scan.nextInt();
                        scan.nextLine();
                        if (index >= 0 && index < messageCount && messageList[index] != null) {
                            System.out.println("Message: " + messageList[index].messageContent);
                        } else {
                            System.out.println("Invalid index.");
                        }
                    } else if (searchType == 3) {
                        System.out.print("Enter word to search (first or last word): ");
                        String word = scan.nextLine();
                        for (int i = 0; i < messageCount; i++) {
                            if (messageList[i] != null && messageList[i].containsWord(word)) {
                                System.out.println("Match Found: " + messageList[i].messageContent);
                            }
                        }
                    }
                } else if (subChoice == 5) {
                    System.out.print("Enter hash to delete: ");
                    int hash = scan.nextInt();
                    scan.nextLine();
                    boolean deleted = false;
                    for (int i = 0; i < messageCount; i++) {
                        if (messageList[i] != null && messageList[i].generateHashCoder() == hash) {
                            System.out.println("Deleted message: " + messageList[i].messageContent);
                            messageList[i] = null;
                            deleted = true;
                            break;
                        }
                    }
                    if (!deleted) System.out.println("Message not found.");
                } else if (subChoice == 6) {
                    TextMessage longest = null;
                    for (int i = 0; i < messageCount; i++) {
                        if (messageList[i] != null &&
                                (longest == null || messageList[i].messageContent.length() > longest.messageContent.length())) {
                            longest = messageList[i];
                        }
                    }
                    if (longest != null) {
                        System.out.println("Longest Message: " + longest.messageContent);
                    } else {
                        System.out.println("No messages available.");
                    }
                }

            } else if (userChoice == 3) {
                System.out.println("Thank you for using the app. Goodbye!");
                exitProgram = true;
            }
        }
    }
}